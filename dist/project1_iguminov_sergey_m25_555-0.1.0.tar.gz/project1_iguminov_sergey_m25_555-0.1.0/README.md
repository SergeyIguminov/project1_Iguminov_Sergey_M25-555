Educational project "Labyrinth game"
Author: Sergey Iguminov